var firebaseConfig = {
    apiKey: "AIzaSyCFlAvP3T2AfG9uRl5U8z2PeA2eXngC1ZA",
    authDomain: "testinglang-5f6ce.firebaseapp.com",
    databaseURL: "https://testinglang-5f6ce.firebaseio.com",
    projectId: "testinglang-5f6ce",
    storageBucket: "testinglang-5f6ce.appspot.com",
    messagingSenderId: "180561543795",
    appId: "1:180561543795:web:75e0ad04eed7903f582006"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

var db = firebase.firestore();

const signupEmail = document.getElementById('signupEmail');
const signupPass = document.getElementById('signupPass');
const phonenumb = document.getElementById('phonenumb');
const fName = document.getElementById('fName');
const lName = document.getElementById('lName');
const singupBtn = document.getElementById('singupBtn');
const signinBtn = document.getElementById('loginBtn');
const loginEmail = document.getElementById('loginEmail');
const loginPass = document.getElementById('loginPass');
const uppanel = document.getElementById('Uppanel');
const inpanel = document.getElementById('Inpanel');
const container = document.getElementById('container');

signinBtn.addEventListener('click', e => {

    const email = loginEmail.value;
    const pass = loginPass.value;
    const auth = firebase.auth();

    const promise = auth.signInWithEmailAndPassword(email, pass)
    promise.catch(e => window.alert("Please enter a valid account."))
})


singupBtn.addEventListener('click', e => {

    const email = loginEmail.value;
    const pass = loginPass.value;


    const auth = firebase.auth();

    const promise = auth.createuserWithEmailAndPassword(email, pass).then(cred => {

        db.collection('users').doc(cred.user.uid).set({
            FirstName: singupBtn['fName'].value,
            LastName: singupBtn['lName'].value,
            PhoneNumber: signinBtn['phonenumb'].value

        })
        promise.catch(e => window.alert("Please enter a valid account."))
    })
})



uppanel.addEventListener('click', () => {
    container.classList.add("right-panel-active");
});

inpanel.addEventListener('click', () => {
    container.classList.remove("right-panel-active");
});